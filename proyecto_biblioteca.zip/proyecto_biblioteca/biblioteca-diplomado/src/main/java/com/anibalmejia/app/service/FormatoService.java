package com.anibalmejia.app.service;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.anibalmejia.app.entity.Formato;

public interface FormatoService {

	public Iterable<Formato> findAll();
	
	public Page<Formato> findAll(Pageable pageable);
	
	public Optional<Formato> findById(Long id);
	
	public Formato save(Formato formato);
	
	public void deleteById(Long id);
}
