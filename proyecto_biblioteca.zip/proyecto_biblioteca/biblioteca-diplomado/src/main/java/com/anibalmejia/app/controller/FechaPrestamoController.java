package com.anibalmejia.app.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anibalmejia.app.entity.FechaPrestamo;
import com.anibalmejia.app.entity.Formato;
import com.anibalmejia.app.service.FechaPrestamoService;

@RestController
@RequestMapping("/api/fecha_prestamo")
public class FechaPrestamoController {
	
	@Autowired
	private FechaPrestamoService fechaPrestamoService;
	
	//crear nueva fecha prestamo
		@PostMapping
		public ResponseEntity<?> create (@RequestBody FechaPrestamo fechaPrestamo){
			return ResponseEntity.status(HttpStatus.CREATED).body(fechaPrestamoService.save(fechaPrestamo)); 
		}
		
		//listar por id
		@GetMapping("/{id}")
		public ResponseEntity<?> read (@PathVariable(value = "id") Long fechaPrestamoId){
			Optional<FechaPrestamo> oFechaPrestamo = fechaPrestamoService.findById(fechaPrestamoId);
			
			if(!oFechaPrestamo.isPresent()) {
				return ResponseEntity.notFound().build();
			}
			
			return ResponseEntity.ok(oFechaPrestamo);
		}
		
		//actualizar fecha prestamo
		@PutMapping("/{id}")
		public ResponseEntity<?> update (@RequestBody FechaPrestamo fechaPrestamoDetails, @PathVariable(value = "id") Long fechaPrestamoId){
			Optional<FechaPrestamo> fechaPrestamo = fechaPrestamoService.findById(fechaPrestamoId);
			
			if(!fechaPrestamo.isPresent()) {
				return ResponseEntity.notFound().build();
			}
			
			fechaPrestamo.get().setFechaInicio(fechaPrestamoDetails.getFechaInicio());
			fechaPrestamo.get().setFechaFin(fechaPrestamoDetails.getFechaFin());
			
			return ResponseEntity.status(HttpStatus.CREATED).body(fechaPrestamoService.save(fechaPrestamo.get()));
		}
		
		//eliminar fecha prestamo
		@DeleteMapping("/{id}")
		public ResponseEntity<?> delete (@PathVariable(value = "id") Long fechaPrestamoId) {
			
			if(!fechaPrestamoService.findById(fechaPrestamoId).isPresent()) {
				return ResponseEntity.notFound().build();
			}
			
			fechaPrestamoService.deleteById(fechaPrestamoId);
			return ResponseEntity.ok().build();
		}
		
		//listar todo
			@GetMapping
			public List<FechaPrestamo> readAll () {
				List<FechaPrestamo> fechaPrestamo = StreamSupport
						.stream(fechaPrestamoService.findAll().spliterator(), false)
						.collect(Collectors.toList());
				
				return fechaPrestamo;
			}

}
