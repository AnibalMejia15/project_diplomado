package com.anibalmejia.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anibalmejia.app.entity.Autor;
import com.anibalmejia.app.repository.AutorRepository;

@Service
public class AutorServiceImpl implements AutorService {
	
	@Autowired
	private AutorRepository autorRepository;

	@Override
	@Transactional(readOnly = true)
	public Iterable<Autor> findAll() {
		return autorRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Page<Autor> findAll(Pageable pageable) {
		return autorRepository.findAll(pageable);
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<Autor> findById(Long id) {
		return autorRepository.findById(id);
	}

	@Override
	@Transactional
	public Autor save(Autor autor) {
		return autorRepository.save(autor);
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		autorRepository.deleteById(id);
		
	}

}
