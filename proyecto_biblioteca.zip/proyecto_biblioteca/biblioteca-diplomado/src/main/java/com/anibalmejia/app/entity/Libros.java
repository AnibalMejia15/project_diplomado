package com.anibalmejia.app.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "books")
public class Libros implements Serializable {
	
	
	private static final long serialVersionUID = 4680010545816885055L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(length = 50)
	private String nombre;
	private int numeropaginas;
	@OneToMany(mappedBy = "autor")
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getNumeropaginas() {
		return numeropaginas;
	}
	public void setNumeropaginas(int numeropaginas) {
		this.numeropaginas = numeropaginas;
	}
	
	

}
