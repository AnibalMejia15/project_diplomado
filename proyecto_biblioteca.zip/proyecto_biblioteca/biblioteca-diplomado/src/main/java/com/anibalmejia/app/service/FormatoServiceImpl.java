package com.anibalmejia.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.anibalmejia.app.entity.Formato;
import com.anibalmejia.app.repository.FormatoRepository;

@Service
public class FormatoServiceImpl implements FormatoService {
	
	@Autowired
	private FormatoRepository formatoRepository;

	@Override
	public Iterable<Formato> findAll() {
		return formatoRepository.findAll();
	}

	@Override
	public Page<Formato> findAll(Pageable pageable) {
		return formatoRepository.findAll(pageable);
	}

	@Override
	public Optional<Formato> findById(Long id) {
		return formatoRepository.findById(id);
	}

	@Override
	public Formato save(Formato formato) {
		return formatoRepository.save(formato);
	}

	@Override
	public void deleteById(Long id) {
		formatoRepository.deleteById(id);
	}

}
