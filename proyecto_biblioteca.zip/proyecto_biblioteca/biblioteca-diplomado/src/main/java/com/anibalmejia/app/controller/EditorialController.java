package com.anibalmejia.app.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anibalmejia.app.entity.editorial;
import com.anibalmejia.app.service.EditorialService;

@RestController
@RequestMapping("/api/editorials")
public class EditorialController {

	@Autowired
	private EditorialService editorialService; 
	
	//crear una nueva editorial
	@PostMapping
	public ResponseEntity<?> create (@RequestBody editorial editorial) {
		return ResponseEntity.status(HttpStatus.CREATED).body(editorialService.save(editorial));
	}
	
	// listar editorial
	@GetMapping("/{id}")
	public ResponseEntity<?> read (@PathVariable(value = "id") Long editorialId ) {
		Optional<editorial> oEditorial = editorialService.findById(editorialId);
		
		if(!oEditorial.isPresent()) {
			return ResponseEntity.notFound().build();
		}
		
		return ResponseEntity.ok(oEditorial);
	}
	
	//actualizar editorial
	@PutMapping("/{id}")
	public ResponseEntity<?> update (@RequestBody editorial editorialDetails, @PathVariable(value = "id") Long editorialId){
		Optional<editorial> editorial = editorialService.findById(editorialId);
		
		if(!editorial.isPresent()) {
			return ResponseEntity.notFound().build();
		}
		
		editorial.get().setNombre(editorialDetails.getNombre());
		
		return ResponseEntity.status(HttpStatus.CREATED).body(editorialService.save(editorial.get()));
	}
	//eliminar editorial
	@DeleteMapping("/{id}")
	
	public ResponseEntity<?> delete (@PathVariable(value = "id") Long editorialId) {
		if(!editorialService.findById(editorialId).isPresent()) {
			return ResponseEntity.notFound().build();
		}
		
		editorialService.deleteById(editorialId);
		return ResponseEntity.ok().build();
	}
	
	//listar todo
	@GetMapping
	public List<editorial> readAll () {
		//en este punto convertimos el iterable con el que veniamos trabajando en una lista con el objeto stream de java 8
		List<editorial> editorials = StreamSupport
				.stream(editorialService.findAll().spliterator(), false)
				.collect(Collectors.toList());
		
		return editorials;
		
	}
		
	
}
