package com.anibalmejia.app.service;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.anibalmejia.app.entity.Ejemplar;

public interface EjemplarService {

	public Iterable<Ejemplar> findAll();
	
	public Page<Ejemplar> findAll(Pageable pageable);
	
	public Optional<Ejemplar> findById(Long id);
	
	public Ejemplar save(Ejemplar ejemplar);
	
	public void deleteById(long id);
	
}
