package com.anibalmejia.app.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anibalmejia.app.entity.Autor;
import com.anibalmejia.app.entity.editorial;
import com.anibalmejia.app.service.AutorService;

@RestController
@RequestMapping("/api/authors")
public class AutorController {
	
	@Autowired
	private AutorService autorService;
	
	//crear un nuevo autor
		@PostMapping
		public ResponseEntity<?> create (@RequestBody Autor editorial) {
			return ResponseEntity.status(HttpStatus.CREATED).body(autorService.save(editorial));
		}
		
		// listar por id
		@GetMapping("/{id}")
		public ResponseEntity<?> read (@PathVariable(value = "id") Long autorId ) {
			Optional<Autor> oAutor = autorService.findById(autorId);
			
			if(!oAutor.isPresent()) {
				return ResponseEntity.notFound().build();
			}
			
			return ResponseEntity.ok(oAutor);
		}
		
		//actualizar autor
		@PutMapping("/{id}")
		public ResponseEntity<?> update (@RequestBody Autor autorDetails, @PathVariable(value = "id") Long autorId){
			Optional<Autor> autor = autorService.findById(autorId);
			
			if(!autor.isPresent()) {
				return ResponseEntity.notFound().build();
			}
			
			autor.get().setNombre(autorDetails.getNombre());
			
			return ResponseEntity.status(HttpStatus.CREATED).body(autorService.save(autor.get()));
		}
		
		//eliminar editorial
		@DeleteMapping("/{id}")
		
		public ResponseEntity<?> delete (@PathVariable(value = "id") Long autorId) {
			if(!autorService.findById(autorId).isPresent()) {
				return ResponseEntity.notFound().build();
			}
			
			autorService.deleteById(autorId);
			return ResponseEntity.ok().build();
		}
		
		//listar todo
		@GetMapping
		public List<Autor> readAll () {
			//en este punto convertimos el iterable con el que veniamos trabajando en una lista con el objeto stream de java 8
			List<Autor> autors = StreamSupport
					.stream(autorService.findAll().spliterator(), false)
					.collect(Collectors.toList());
			
			return autors;
			
		}
}
