package com.anibalmejia.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.anibalmejia.app.entity.user;

//se extiende desde JpaRepository con el fin de hacer paginacion desde el lado del servidor
@Repository
public interface UserRepository extends JpaRepository<user, Long> {

}
