package com.anibalmejia.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anibalmejia.app.entity.editorial;
import com.anibalmejia.app.repository.EditorialRepository;

@Service
public class EditorialServiceImpl implements EditorialService{
	
	@Autowired
	private EditorialRepository editorialRepository;

	@Override
	@Transactional(readOnly = true)
	public Iterable<editorial> findAll() {
		return editorialRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Page<editorial> findAll(Pageable pageable) {
		return editorialRepository.findAll(pageable);
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<editorial> findById(Long id) {
		return editorialRepository.findById(id);
	}

	@Override
	@Transactional
	public editorial save(editorial editorial) {
		return editorialRepository.save(editorial);
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		editorialRepository.deleteById(id);	
	}

}
