package com.anibalmejia.app.service;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.anibalmejia.app.entity.Formato;
import com.anibalmejia.app.entity.TipoUsuario;

public interface TipoUsuarioService {

	public Iterable<TipoUsuario> findAll();
	
	public Page<TipoUsuario> findAll(Pageable pageable);
	
	public Optional<TipoUsuario> findById(Long id);
	
	public TipoUsuario save(TipoUsuario tipoUsuario);
	
	public void deleteById(Long id);
}
