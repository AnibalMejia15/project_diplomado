package com.anibalmejia.app.service;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.anibalmejia.app.entity.editorial;

public interface EditorialService {
	
	public Iterable<editorial> findAll();
	
	public Page<editorial> findAll(Pageable pageable);
	
	public Optional<editorial> findById(Long id);
	
	public editorial save(editorial editorial);
	
	public void deleteById(Long id);

}
