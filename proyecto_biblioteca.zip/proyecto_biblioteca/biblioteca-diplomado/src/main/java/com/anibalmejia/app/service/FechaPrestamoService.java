package com.anibalmejia.app.service;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.anibalmejia.app.entity.FechaPrestamo;


public interface FechaPrestamoService {

public Iterable<FechaPrestamo> findAll();
	
	public Page<FechaPrestamo> findAll(Pageable pageable);
	
	public Optional<FechaPrestamo> findById(Long id);
	
	public FechaPrestamo save(FechaPrestamo fechaPrestamo);
	
	public void deleteById(Long id);
}
