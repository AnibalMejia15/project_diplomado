package com.anibalmejia.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anibalmejia.app.entity.Ejemplar;
import com.anibalmejia.app.repository.EjemplarRepository;

@Service
public class EjemplarServiceImpl implements EjemplarService {
	
	@Autowired
	private EjemplarRepository ejemplarRepository;

	@Override
	@Transactional(readOnly = true)
	public Iterable<Ejemplar> findAll() {
		return ejemplarRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Page<Ejemplar> findAll(Pageable pageable) {
		return ejemplarRepository.findAll(pageable);
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<Ejemplar> findById(Long id) {
		return ejemplarRepository.findById(id);
	}

	@Override
	@Transactional
	public Ejemplar save(Ejemplar ejemplar) {
		return ejemplarRepository.save(ejemplar);
	}

	@Override
	@Transactional
	public void deleteById(long id) {
		ejemplarRepository.deleteById(id);
	}

}
