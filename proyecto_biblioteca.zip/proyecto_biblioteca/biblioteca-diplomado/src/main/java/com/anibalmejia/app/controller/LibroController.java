package com.anibalmejia.app.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anibalmejia.app.entity.Libros;
import com.anibalmejia.app.entity.editorial;
import com.anibalmejia.app.service.LibroService;

@RestController
@RequestMapping("/api/libros")
public class LibroController {

	@Autowired
	private LibroService libroService;
	
	//crear libro
	@PostMapping
	public ResponseEntity<?> create (@RequestBody Libros libros) {
		return ResponseEntity.status(HttpStatus.CREATED).body(libroService.save(libros));
	}
	
	// listar libros por id
		@GetMapping("/{id}")
		public ResponseEntity<?> read (@PathVariable(value = "id") Long libroId ) {
			Optional<Libros> oLibros = libroService.findById(libroId);
			
			if(!oLibros.isPresent()) {
				return ResponseEntity.notFound().build();
			}
			
			return ResponseEntity.ok(oLibros);
		}
		
		//actualizar libros
		@PutMapping("/{id}")
		public ResponseEntity<?> update (@RequestBody Libros librosDetails, @PathVariable(value = "id") Long libroId){
			Optional<Libros> libro = libroService.findById(libroId);
			
			if(!libro.isPresent()) {
				return ResponseEntity.notFound().build();
			}
			
			libro.get().setNombre(librosDetails.getNombre());
			libro.get().setNumeropaginas(librosDetails.getNumeropaginas());
			
			return ResponseEntity.status(HttpStatus.CREATED).body(libroService.save(libro.get()));
		}
		
		//eliminar editorial
		@DeleteMapping("/{id}")
		
		public ResponseEntity<?> delete (@PathVariable(value = "id") Long libroId) {
			if(!libroService.findById(libroId).isPresent()) {
				return ResponseEntity.notFound().build();
			}
			
			libroService.deleteById(libroId);
			return ResponseEntity.ok().build();
		}
		
		//listar todo
		@GetMapping
		public List<Libros> readAll () {
			//en este punto convertimos el iterable con el que veniamos trabajando en una lista con el objeto stream de java 8
			List<Libros> libros = StreamSupport
					.stream(libroService.findAll().spliterator(), false)
					.collect(Collectors.toList());
			
			return libros;
			
		}
	
}
