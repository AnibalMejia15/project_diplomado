package com.anibalmejia.app.service;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.anibalmejia.app.entity.Autor;

public interface AutorService {
	
public Iterable<Autor> findAll();
	
	public Page<Autor> findAll(Pageable pageable);
	
	public Optional<Autor> findById(Long id);
	
	public Autor save(Autor autor);
	
	public void deleteById(Long id);

}
