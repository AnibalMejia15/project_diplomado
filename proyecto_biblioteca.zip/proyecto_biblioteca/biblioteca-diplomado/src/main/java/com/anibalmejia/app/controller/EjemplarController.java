package com.anibalmejia.app.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anibalmejia.app.entity.Ejemplar;
import com.anibalmejia.app.service.EjemplarService;

@RestController
@RequestMapping("/api/ejemplares")
public class EjemplarController {
	
	@Autowired
	private EjemplarService ejemplarService;
	
	//crear nuevo ejemplar
	@PostMapping
	public ResponseEntity<?> create (@RequestBody Ejemplar ejemplar){
		return ResponseEntity.status(HttpStatus.CREATED).body(ejemplarService.save(ejemplar));
	}
	
	//listar ejemplares por id
	@GetMapping("/{id}")
	public ResponseEntity<?> read (@PathVariable(value = "id") Long ejemplarId){
		Optional<Ejemplar> oEjemplar = ejemplarService.findById(ejemplarId);
		
		if(!oEjemplar.isPresent()) {
			return ResponseEntity.notFound().build();
		}
		
		return ResponseEntity.ok(oEjemplar);
	}
	
	//actualizar ejemplares
	@PutMapping("/{id}")
	public ResponseEntity<?> update (@RequestBody Ejemplar ejemplarDetails, @PathVariable(value = "id") Long ejemplarId){
		Optional<Ejemplar> ejemplar = ejemplarService.findById(ejemplarId);
		
		if(!ejemplar.isPresent()) {
			return ResponseEntity.notFound().build();
		}
		
		ejemplar.get().setNombre(ejemplarDetails.getNombre());
		
		return ResponseEntity.status(HttpStatus.CREATED).body(ejemplarService.save(ejemplar.get()));
		
	}
	
	//eliminar ejemplares
	@DeleteMapping("/{id}")
	public ResponseEntity<?> delete (@PathVariable(value = "id") Long ejemplarId) {
		
		if(!ejemplarService.findById(ejemplarId).isPresent()) {
			return ResponseEntity.notFound().build();
		}
		
		ejemplarService.deleteById(ejemplarId);
		return ResponseEntity.ok().build();
	}
	
	//listar todo
	@GetMapping
	public List<Ejemplar> readAll () {
		List<Ejemplar> ejemplar = StreamSupport
				.stream(ejemplarService.findAll().spliterator(), false)
				.collect(Collectors.toList());
		
		return ejemplar;
	}
}
