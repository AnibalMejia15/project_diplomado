package com.anibalmejia.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.anibalmejia.app.entity.Libros;
import com.anibalmejia.app.repository.LibrosRepository;

@Service
public class LibroServiceImpl implements LibroService {

	@Autowired
	public LibrosRepository libroRepository;
	
	@Override
	@Transactional(readOnly = true)
	public Iterable<Libros> findAll() {
		return libroRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Page<Libros> findAll(Pageable pageable) {
		return libroRepository.findAll(pageable);
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<Libros> findById(Long id) {
		return libroRepository.findById(id);
	}

	@Override
	@Transactional
	public Libros save(Libros libros) {
		return libroRepository.save(libros);
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		libroRepository.deleteById(id);
	}
	

	
}
