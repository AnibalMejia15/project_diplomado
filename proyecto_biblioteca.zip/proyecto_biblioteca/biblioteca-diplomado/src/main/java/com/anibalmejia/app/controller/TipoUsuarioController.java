package com.anibalmejia.app.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anibalmejia.app.entity.TipoUsuario;
import com.anibalmejia.app.service.TipoUsuarioService;

@RestController
@RequestMapping("/api/tipo_usuario")
public class TipoUsuarioController {
	
	@Autowired
	private TipoUsuarioService tipoUsuarioService;
	
	//crear nuevo tipo usuario
		@PostMapping
		public ResponseEntity<?> create (@RequestBody TipoUsuario tipoUsuario){
			return ResponseEntity.status(HttpStatus.CREATED).body(tipoUsuarioService.save(tipoUsuario)); 
		}
		
		//listar por id
		@GetMapping("/{id}")
		public ResponseEntity<?> read (@PathVariable(value = "id") Long tipoUsuarioId){
			Optional<TipoUsuario> oTipoUsuario = tipoUsuarioService.findById(tipoUsuarioId);
			
			if(!oTipoUsuario.isPresent()) {
				return ResponseEntity.notFound().build();
			}
			
			return ResponseEntity.ok(oTipoUsuario);
		}
		
		//actualizar tipo usuario
		@PutMapping("/{id}")
		public ResponseEntity<?> update (@RequestBody TipoUsuario tipoUsuarioDetails, @PathVariable(value = "id") Long tipoUsuarioId){
			Optional<TipoUsuario> tipoUsuario = tipoUsuarioService.findById(tipoUsuarioId);
			
			if(!tipoUsuario.isPresent()) {
				return ResponseEntity.notFound().build();
			}
			
			tipoUsuario.get().setDescripcion(tipoUsuarioDetails.getDescripcion());
			
			return ResponseEntity.status(HttpStatus.CREATED).body(tipoUsuarioService.save(tipoUsuario.get()));
		}
		
		//eliminar tipo usuario
		@DeleteMapping("/{id}")
		public ResponseEntity<?> delete (@PathVariable(value = "id") Long tipoUsuarioId) {
			
			if(!tipoUsuarioService.findById(tipoUsuarioId).isPresent()) {
				return ResponseEntity.notFound().build();
			}
			
			tipoUsuarioService.deleteById(tipoUsuarioId);
			return ResponseEntity.ok().build();
		}
		
		//listar todo
			@GetMapping
			public List<TipoUsuario> readAll () {
				List<TipoUsuario> tipoUsuario = StreamSupport
						.stream(tipoUsuarioService.findAll().spliterator(), false)
						.collect(Collectors.toList());
				
				return tipoUsuario;
			}

}
