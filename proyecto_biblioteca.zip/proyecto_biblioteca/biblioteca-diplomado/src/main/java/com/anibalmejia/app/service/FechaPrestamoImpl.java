package com.anibalmejia.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.anibalmejia.app.entity.FechaPrestamo;
import com.anibalmejia.app.repository.FechaPrestamoRepository;

@Service
public class FechaPrestamoImpl implements FechaPrestamoService {
	
	@Autowired
	private FechaPrestamoRepository fechaPrestamoRepository;

	@Override
	public Iterable<FechaPrestamo> findAll() {
		return fechaPrestamoRepository.findAll();
	}

	@Override
	public Page<FechaPrestamo> findAll(Pageable pageable) {
		return fechaPrestamoRepository.findAll(pageable);
	}

	@Override
	public Optional<FechaPrestamo> findById(Long id) {
		return fechaPrestamoRepository.findById(id);
	}

	@Override
	public FechaPrestamo save(FechaPrestamo fechaPrestamo) {
		return fechaPrestamoRepository.save(fechaPrestamo);
	}

	@Override
	public void deleteById(Long id) {
		fechaPrestamoRepository.deleteById(id);
	}

}
