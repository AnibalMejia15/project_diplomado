package com.anibalmejia.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.anibalmejia.app.entity.TipoUsuario;
import com.anibalmejia.app.repository.TipoUsuarioRepository;

@Service
public class TipoUsuarioImpl implements TipoUsuarioService {
	
	@Autowired
	private TipoUsuarioRepository tipoUsuarioRepository;

	@Override
	public Iterable<TipoUsuario> findAll() {
		return tipoUsuarioRepository.findAll();
	}

	@Override
	public Page<TipoUsuario> findAll(Pageable pageable) {
		return tipoUsuarioRepository.findAll(pageable);
	}

	@Override
	public Optional<TipoUsuario> findById(Long id) {
		return tipoUsuarioRepository.findById(id);
	}

	@Override
	public TipoUsuario save(TipoUsuario tipoUsuario) {
		return tipoUsuarioRepository.save(tipoUsuario);
	}

	@Override
	public void deleteById(Long id) {
		tipoUsuarioRepository.deleteById(id);
	}

}
