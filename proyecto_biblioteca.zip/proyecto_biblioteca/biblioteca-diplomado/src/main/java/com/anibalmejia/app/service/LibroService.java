package com.anibalmejia.app.service;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.anibalmejia.app.entity.Libros;

public interface LibroService {
	
	public Iterable<Libros> findAll();
	
	public Page<Libros> findAll(Pageable pageable);
	
	public Optional<Libros> findById(Long id);
	
	public Libros save(Libros libros);
	
	public void deleteById(Long id);
}
